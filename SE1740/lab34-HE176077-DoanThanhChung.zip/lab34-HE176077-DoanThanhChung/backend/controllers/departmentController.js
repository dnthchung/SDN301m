const db = require("../models");
const Department = db.department;

module.exports = {};
