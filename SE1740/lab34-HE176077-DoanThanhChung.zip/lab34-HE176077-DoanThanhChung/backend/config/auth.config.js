module.exports = {
  secret: "code gen access token",
  jwtExpiration: 30,
  jwtRefreshExpiration: 120,
};
