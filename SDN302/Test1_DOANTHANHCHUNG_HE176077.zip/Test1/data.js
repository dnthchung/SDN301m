const users = [
  {
    account: "admin1",
    password: "123",
    name: "Thich tu do",
    gender: 1,
    email: "tudo@gmail.com",
  },
  {
    account: "user1",
    password: "456",
    name: "Thich moi thu",
    gender: 1,
    email: "tudo@gmail.com",
  },
];

module.exports = users;
