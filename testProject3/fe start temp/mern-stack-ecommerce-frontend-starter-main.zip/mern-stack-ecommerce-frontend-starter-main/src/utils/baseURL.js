const baseURL = "http://localhost:9020/api/v1/";

export default baseURL;
