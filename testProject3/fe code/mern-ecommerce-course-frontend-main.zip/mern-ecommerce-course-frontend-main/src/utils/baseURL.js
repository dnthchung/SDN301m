// const baseURL = "http://localhost:2030/api/v1";
const baseURL = "https://nodejs-ecommerce-api.onrender.com/api/v1";
export default baseURL;
