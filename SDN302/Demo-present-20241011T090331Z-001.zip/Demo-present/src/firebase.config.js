const { initializeApp } = require("firebase/app");
const { getStorage, ref } = require("firebase/storage");

const firebaseConfig = {

  };

  const app = initializeApp(firebaseConfig);
  const storage = getStorage(app);
  const storageRef = ref(storage);

module.exports = { firebaseConfig, storage, storageRef };