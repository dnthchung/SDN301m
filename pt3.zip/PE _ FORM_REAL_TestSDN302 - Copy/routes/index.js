const movieRouter = require("./movieRoute");

module.exports = { movieRouter };
